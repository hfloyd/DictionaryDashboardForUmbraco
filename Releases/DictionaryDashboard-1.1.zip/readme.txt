
### Documentation ###

Please see http://our.umbraco.org/projects/backoffice-extensions/dictionary-dashboard for more details about this package.



### Installation ###

Install this package as a local package in Umbraco.

If updating from a previous version, you should uninstall the previous version before installing the latest version of this package.

A dashboard tab and three dashboard controls will be added to the Content section in Umbraco. 

You can further configure the dashboard controls in the /config/Dashboard.config file.



### Questions / comments ###

https://our.umbraco.org/projects/backoffice-extensions/dictionary-dashboard/feedback

### Source Code ###

https://github.com/hfloyd/DictionaryDashboardForUmbraco